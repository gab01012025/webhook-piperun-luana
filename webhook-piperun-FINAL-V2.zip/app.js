require('dotenv').config();require('dotenv').config();const express = require('express');

const express = require('express');

const cors = require('cors');const express = require('express');const app = express();

const app = express();

const cors = require('cors');

// Middlewares

app.use(cors());const webhookDiagnostic = require('./src/services/webhookDiagnostic');app.get('/', (req, res) => {

app.use(express.json());

app.use(express.urlencoded({ extended: true }));const metaAdsService = require('./src/services/metaAdsService');    res.send('Minimal App is Running!');



// Rota principalconst piperunService = require('./src/services/piperunService');});

app.get('/', function(req, res) {

    res.json({const logger = require('./src/utils/logger');

        message: 'Piperun to Meta Ads Webhook Integration',

        status: 'active',module.exports = app;

        version: '1.0.0',const app = express();

        webhook_url: '/webhook/piperun'

    });// Middlewares

});app.use(cors());

app.use(express.json());

// Webhook do Piperunapp.use(express.urlencoded({ extended: true }));

app.post('/webhook/piperun', function(req, res) {

    const axios = require('axios');// Middleware de logging

    app.use((req, res, next) => {

    console.log('Webhook recebido:', JSON.stringify(req.body));    logger.info(`${req.method} ${req.path} - ${req.ip}`);

        next();

    // Extrair dados do Piperun});

    const data = req.body;

    const email = data.email || data.person_email || '';// Rotas principais

    const phone = data.phone || data.person_phone || '';app.get('/', (req, res) => {

    const name = data.name || data.person_name || '';    res.json({

            message: 'Piperun → Meta Ads Webhook Integration',

    // Preparar evento para Meta        status: 'active',

    const eventData = {        version: '1.0.0',

        data: [{        endpoints: {

            event_name: 'Lead',            webhook: '/webhook/piperun',

            event_time: Math.floor(Date.now() / 1000),            diagnostic: '/diagnostic',

            action_source: 'website',            test: '/test-connection'

            user_data: {        }

                em: email ? require('crypto').createHash('sha256').update(email.toLowerCase().trim()).digest('hex') : undefined,    });

                ph: phone ? require('crypto').createHash('sha256').update(phone.replace(/\D/g, '')).digest('hex') : undefined,});

                fn: name ? require('crypto').createHash('sha256').update(name.toLowerCase().trim()).digest('hex') : undefined

            }// Rota do webhook principal do Piperun

        }],app.post('/webhook/piperun', async (req, res) => {

        test_event_code: process.env.META_TEST_CODE    try {

    };        logger.info('Webhook recebido do Piperun', { body: req.body });

            

    // Enviar para Meta        // 1. Diagnóstico dos dados recebidos

    const url = 'https://graph.facebook.com/v18.0/' + process.env.META_PIXEL_ID + '/events';        const diagnostic = await webhookDiagnostic.analyzePiperunData(req.body);

            

    axios.post(url, eventData, {        if (!diagnostic.isValid) {

        params: {            logger.error('Dados inválidos recebidos do Piperun', diagnostic.errors);

            access_token: process.env.META_ACCESS_TOKEN            return res.status(400).json({

        }                success: false,

    })                message: 'Dados inválidos',

    .then(function(response) {                errors: diagnostic.errors

        console.log('Sucesso Meta:', response.data);            });

        res.json({        }

            success: true,

            message: 'Evento enviado para Meta Ads',        // 2. Processar e normalizar dados

            meta_response: response.data        const processedData = await piperunService.processWebhookData(req.body);

        });        

    })        // 3. Enviar para Meta Ads

    .catch(function(error) {        const metaResult = await metaAdsService.sendEvent(processedData);

        console.error('Erro Meta:', error.response ? error.response.data : error.message);        

        res.status(500).json({        if (metaResult.success) {

            success: false,            logger.info('Evento enviado com sucesso para Meta Ads', { 

            message: 'Erro ao enviar para Meta Ads',                eventId: metaResult.eventId,

            error: error.response ? error.response.data : error.message                status: metaResult.status 

        });            });

    });            

});            res.json({

                success: true,

module.exports = app;                message: 'Evento processado e enviado para Meta Ads',

                eventId: metaResult.eventId,
                status: metaResult.status
            });
        } else {
            throw new Error(metaResult.error || 'Falha ao enviar evento para Meta Ads');
        }

    } catch (error) {
        logger.error('Erro ao processar webhook do Piperun', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor',
            error: process.env.NODE_ENV === 'development' ? error.message : 'Erro interno'
        });
    }
});

// Rota de diagnóstico
app.get('/diagnostic', async (req, res) => {
    try {
        const diagnostic = await webhookDiagnostic.runCompleteDiagnostic();
        res.json(diagnostic);
    } catch (error) {
        logger.error('Erro no diagnóstico', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao executar diagnóstico',
            error: error.message
        });
    }
});

// Rota de teste de conexão
app.get('/test-connection', async (req, res) => {
    try {
        const metaTest = await metaAdsService.testConnection();
        const piperunTest = await piperunService.testConnection();
        
        res.json({
            metaAds: metaTest,
            piperun: piperunTest,
            overall: metaTest.success && piperunTest.success ? 'success' : 'error'
        });
    } catch (error) {
        logger.error('Erro no teste de conexão', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao testar conexões',
            error: error.message
        });
    }
});

// Middleware de tratamento de erros
app.use((error, req, res, next) => {
    logger.error('Erro não tratado', error);
    res.status(500).json({
        success: false,
        message: 'Erro interno do servidor'
    });
});

module.exports = app;
