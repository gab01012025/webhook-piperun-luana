require('dotenv').config();
const express = require('express');
const cors = require('cors');
const webhookDiagnostic = require('./src/services/webhookDiagnostic');
const metaAdsService = require('./src/services/metaAdsService');
const piperunService = require('./src/services/piperunService');
const logger = require('./src/utils/logger');

const app = express();
// // // const PORT = process.env.PORT || 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Middleware de logging
app.use((req, res, next) => {
    logger.info(`${req.method} ${req.path} - ${req.ip}`);
    next();
});

// Rotas principais
app.get('/', (req, res) => {
    res.json({
        message: 'Piperun → Meta Ads Webhook Integration',
        status: 'active',
        version: '1.0.0',
        endpoints: {
            webhook: '/webhook/piperun',
            diagnostic: '/diagnostic',
            test: '/test-connection'
        }
    });
});

// Rota do webhook principal do Piperun
app.post('/webhook/piperun', async (req, res) => {
    try {
        logger.info('Webhook recebido do Piperun', { body: req.body });
        
        // 1. Diagnóstico dos dados recebidos
        const diagnostic = await webhookDiagnostic.analyzePiperunData(req.body);
        
        if (!diagnostic.isValid) {
            logger.error('Dados inválidos recebidos do Piperun', diagnostic.errors);
            return res.status(400).json({
                success: false,
                message: 'Dados inválidos',
                errors: diagnostic.errors
            });
        }

        // 2. Processar e normalizar dados
        const processedData = await piperunService.processWebhookData(req.body);
        
        // 3. Enviar para Meta Ads
        const metaResult = await metaAdsService.sendEvent(processedData);
        
        if (metaResult.success) {
            logger.info('Evento enviado com sucesso para Meta Ads', { 
                eventId: metaResult.eventId,
                status: metaResult.status 
            });
            
            res.json({
                success: true,
                message: 'Evento processado e enviado para Meta Ads',
                eventId: metaResult.eventId,
                status: metaResult.status
            });
        } else {
            throw new Error(metaResult.error || 'Falha ao enviar evento para Meta Ads');
        }

    } catch (error) {
        logger.error('Erro ao processar webhook do Piperun', error);
        res.status(500).json({
            success: false,
            message: 'Erro interno do servidor',
            error: process.env.NODE_ENV === 'development' ? error.message : 'Erro interno'
        });
    }
});

// Rota de diagnóstico
app.get('/diagnostic', async (req, res) => {
    try {
        const diagnostic = await webhookDiagnostic.runCompleteDiagnostic();
        res.json(diagnostic);
    } catch (error) {
        logger.error('Erro no diagnóstico', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao executar diagnóstico',
            error: error.message
        });
    }
});

// Rota de teste de conexão
app.get('/test-connection', async (req, res) => {
    try {
        const metaTest = await metaAdsService.testConnection();
        const piperunTest = await piperunService.testConnection();
        
        res.json({
            metaAds: metaTest,
            piperun: piperunTest,
            overall: metaTest.success && piperunTest.success ? 'success' : 'error'
        });
    } catch (error) {
        logger.error('Erro no teste de conexão', error);
        res.status(500).json({
            success: false,
            message: 'Erro ao testar conexões',
            error: error.message
        });
    }
});

// Middleware de tratamento de erros
app.use((error, req, res, next) => {
    logger.error('Erro não tratado', error);
    res.status(500).json({
        success: false,
        message: 'Erro interno do servidor'
    });
});

// Inicializar servidor
/*
/*
app.listen(PORT, () => {
    logger.info(`Server is running on port ${PORT}`);
});
*/
*/

module.exports = app;